// InstaCheck - popup.js v2 (with waiting ticker)

const startBtn     = document.getElementById('startBtn');
const downloadBtn  = document.getElementById('downloadBtn');
const resetBtn     = document.getElementById('resetBtn');
const statusCard   = document.getElementById('statusCard');
const statusMsg    = document.getElementById('statusMsg');
const progressWrap = document.getElementById('progressWrap');
const progressFill = document.getElementById('progressFill');
const pulseDot     = document.getElementById('pulseDot');
const countDisplay = document.getElementById('countDisplay');
const countNum     = document.getElementById('countNum');
const countLabel   = document.getElementById('countLabel');
const hintText     = document.getElementById('hintText');
const tabFollowers = document.getElementById('tabFollowers');
const tabFollowing = document.getElementById('tabFollowing');
const waitingTicker = document.getElementById('waitingTicker');
const tickerText   = document.getElementById('tickerText');
const tickerTag    = document.getElementById('tickerTag');

let collectedUsernames = [];
let currentMode = 'followers';
let tickerInterval = null;
let tickerIndex = 0;

// ─── Waiting Messages ─────────────────────────────────────────────────────────
// Each entry: { tag, type: 'fun'|'fact', text }

const TICKER_MESSAGES = [
  // Fun / waiting
  { tag: 'just a sec', type: 'fun', text: "Just a second… or maybe two. Probably two." },
  { tag: 'hang tight', type: 'fun', text: "Scrolling faster than you ever could. You're welcome." },
  { tag: 'anytime now', type: 'fun', text: "Anytime now… we're waiting on Instagram, not the other way around." },
  { tag: 'still here', type: 'fun', text: "Still going! Instagram hides these names deep. Like, really deep." },
  { tag: 'pro tip', type: 'fun', text: "Did you know staring at this screen makes it go faster? (It doesn't.)" },
  { tag: 'loading…', type: 'fun', text: "Counting heads… virtually. No actual heads were involved." },
  { tag: 'almost?', type: 'fun', text: "We're not lost, we're just exploring the bottom of your list." },
  { tag: 'patience', type: 'fun', text: "Instagram: the app that loads stories instantly but makes lists a nightmare." },
  { tag: 'fun fact', type: 'fun', text: "Plot twist: some of these people have never watched a single one of your stories." },
  { tag: 'sipping coffee', type: 'fun', text: "This is a great time to grab a coffee. We'll wait. Actually, we won't." },
  { tag: 'tech speak', type: 'fun', text: "Executing scroll loop iteration #∞. Results: pending. Vibes: immaculate." },
  { tag: 'motivation', type: 'fun', text: "Every username we find is one step closer to your cleanest feed ever." },
  { tag: 'confession', type: 'fun', text: "We've already scrolled past people you forgot you followed in 2019." },
  { tag: 'solidarity', type: 'fun', text: "Your future self will thank you for this. Probably." },
  // Facts
  { tag: 'did you know', type: 'fact', text: "Instagram has over 2 billion monthly active users as of 2024." },
  { tag: 'insta fact', type: 'fact', text: "The average Instagram user spends about 30 minutes per day on the app." },
  { tag: 'wild stat', type: 'fact', text: "Over 100 million photos and videos are shared on Instagram every single day." },
  { tag: 'history', type: 'fact', text: "Instagram launched in October 2010 and hit 1 million users in just 2 months." },
  { tag: 'money talk', type: 'fact', text: "Facebook bought Instagram in 2012 for ~$1 billion. It's now worth hundreds of billions." },
  { tag: 'algorithm', type: 'fact', text: "Instagram's algorithm considers relationship strength, interest score, and recency to rank your feed." },
  { tag: 'stories', type: 'fact', text: "Instagram Stories was launched in 2016, directly inspired by Snapchat's format." },
  { tag: 'engagement', type: 'fact', text: "Photos with faces get 38% more likes on average than photos without faces." },
  { tag: 'hashtags', type: 'fact', text: "Posts with at least one hashtag get 12.6% more engagement than those without." },
  { tag: 'reels era', type: 'fact', text: "Reels get 22% more interaction than regular video posts on Instagram." },
];

// shuffle so it feels fresh each run
function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

let shuffledMessages = shuffle(TICKER_MESSAGES);

function startTicker() {
  tickerIndex = 0;
  shuffledMessages = shuffle(TICKER_MESSAGES);
  waitingTicker.style.display = 'block';
  showTickerMessage(shuffledMessages[0]);

  tickerInterval = setInterval(() => {
    tickerIndex = (tickerIndex + 1) % shuffledMessages.length;
    animateTickerChange(shuffledMessages[tickerIndex]);
  }, 3500);
}

function stopTicker() {
  clearInterval(tickerInterval);
  tickerInterval = null;
  waitingTicker.style.display = 'none';
}

function showTickerMessage(msg) {
  tickerTag.textContent = msg.tag;
  tickerTag.className = `ticker-tag ${msg.type}`;
  tickerText.textContent = msg.text;
  tickerText.style.opacity = '1';
  tickerText.style.transform = 'translateY(0)';
}

function animateTickerChange(msg) {
  // Fade out current
  tickerText.style.transition = 'opacity 0.35s ease, transform 0.35s ease';
  tickerText.style.opacity = '0';
  tickerText.style.transform = 'translateY(-8px)';

  setTimeout(() => {
    tickerTag.textContent = msg.tag;
    tickerTag.className = `ticker-tag ${msg.type}`;
    tickerText.textContent = msg.text;
    // Snap to bottom position silently
    tickerText.style.transition = 'none';
    tickerText.style.transform = 'translateY(8px)';
    tickerText.style.opacity = '0';

    // Force reflow
    tickerText.offsetHeight;

    // Fade in from below
    tickerText.style.transition = 'opacity 0.35s ease, transform 0.35s ease';
    tickerText.style.opacity = '1';
    tickerText.style.transform = 'translateY(0)';
  }, 380);
}

// ─── Tab Switching ─────────────────────────────────────────────────────────────

function setMode(mode) {
  currentMode = mode;
  collectedUsernames = [];
  downloadBtn.disabled = true;
  countDisplay.style.display = 'none';

  tabFollowers.classList.toggle('active', mode === 'followers');
  tabFollowing.classList.toggle('active', mode === 'following');

  if (mode === 'followers') {
    hintText.innerHTML = `Go to your Instagram profile → tap <span>Followers</span> to open the list → then press Start above.`;
    setStatus(`Open your Instagram <strong>Followers</strong> list, then press Start.`, '');
  } else {
    hintText.innerHTML = `Go to your Instagram profile → tap <span>Following</span> to open the list → then press Start above.`;
    setStatus(`Open your Instagram <strong>Following</strong> list, then press Start.`, '');
  }
}

tabFollowers.addEventListener('click', () => setMode('followers'));
tabFollowing.addEventListener('click', () => setMode('following'));

// ─── Status Helpers ────────────────────────────────────────────────────────────

function setStatus(msg, state = '', showProgress = false, progressPct = 0) {
  statusCard.className = 'status-card' + (state ? ' ' + state : '');
  statusMsg.innerHTML = msg;

  pulseDot.className = 'pulse-dot';
  if (state === 'error')        pulseDot.classList.add('error');
  else if (state === 'success') pulseDot.classList.add('done');
  else if (showProgress)        pulseDot.classList.add('running');

  progressWrap.style.display = showProgress ? 'block' : 'none';
  progressFill.style.width   = progressPct + '%';
}

function showCount(n, done = false) {
  countDisplay.style.display = 'block';
  countNum.textContent = n.toLocaleString();
  countLabel.textContent = done
    ? (currentMode === 'followers' ? 'followers found' : 'accounts following')
    : 'found so far…';
}

// ─── Active Tab ────────────────────────────────────────────────────────────────

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

// ─── Start ─────────────────────────────────────────────────────────────────────

startBtn.addEventListener('click', async () => {
  const tab = await getActiveTab();

  if (!tab.url || !tab.url.includes('instagram.com')) {
    setStatus('⚠️ Please navigate to <strong>Instagram</strong> first.', 'error');
    return;
  }

  startBtn.disabled    = true;
  downloadBtn.disabled = true;
  collectedUsernames   = [];
  countDisplay.style.display = 'none';

  const listName = currentMode === 'followers' ? 'Followers' : 'Following';
  setStatus(`Scraping your <strong>${listName}</strong> list…`, 'scraping', true, 5);
  startTicker();

  chrome.tabs.sendMessage(tab.id, { action: 'START_SCRAPE' }, (response) => {
    if (chrome.runtime.lastError) {
      stopTicker();
      setStatus('❌ Could not connect to Instagram. Please refresh Instagram and try again.', 'error');
      startBtn.disabled = false;
    }
  });
});

// ─── Reset ─────────────────────────────────────────────────────────────────────

resetBtn.addEventListener('click', async () => {
  stopTicker();
  collectedUsernames   = [];
  startBtn.disabled    = false;
  downloadBtn.disabled = true;
  countDisplay.style.display = 'none';

  const listName = currentMode === 'followers' ? 'Followers' : 'Following';
  setStatus(`Open your Instagram <strong>${listName}</strong> list, then press Start.`, '');

  const tab = await getActiveTab();
  if (tab && tab.url && tab.url.includes('instagram.com')) {
    chrome.tabs.sendMessage(tab.id, { action: 'STOP_SCRAPE' });
  }
});

// ─── Download ──────────────────────────────────────────────────────────────────

downloadBtn.addEventListener('click', () => {
  if (!collectedUsernames.length) return;
  const content = collectedUsernames.join('\n');
  const blob    = new Blob([content], { type: 'text/plain' });
  const url     = URL.createObjectURL(blob);
  const a       = document.createElement('a');
  const dateStr = new Date().toISOString().slice(0, 10);
  const prefix  = currentMode === 'followers' ? 'followers' : 'following';
  a.href     = url;
  a.download = `${prefix}_${dateStr}.txt`;
  a.click();
  URL.revokeObjectURL(url);
});

// ─── Messages from Content Script ──────────────────────────────────────────────

chrome.runtime.onMessage.addListener((message) => {
  if (message.action === 'SCRAPE_PROGRESS') {
    const { count, done } = message;

    if (done) {
      stopTicker();
      collectedUsernames = message.usernames;
      const n = collectedUsernames.length;
      setStatus(`Done! Export your list below.`, 'success', true, 100);
      showCount(n, true);
      startBtn.disabled    = false;
      downloadBtn.disabled = false;
    } else {
      setStatus(`Scrolling through your list…`, 'scraping', true, Math.min(90, 5 + (count / 12)));
      showCount(count, false);
    }
  }

  if (message.action === 'SCRAPE_ERROR') {
    stopTicker();
    setStatus(`❌ ${message.error}`, 'error');
    startBtn.disabled = false;
    countDisplay.style.display = 'none';
  }
});
