/* InstaCheck - content script v2 */
(() => {
  let isScraping = false;
  let collected = new Set();

  function sendProgress(done = false) {
    chrome.runtime.sendMessage({
      action: 'SCRAPE_PROGRESS',
      count: collected.size,
      done,
      usernames: done ? Array.from(collected) : []
    });
  }

  function sendError(msg) {
    chrome.runtime.sendMessage({ action: 'SCRAPE_ERROR', error: msg });
  }

  function sleep(ms) {
    return new Promise(r => setTimeout(r, ms));
  }

  const BLOCKED = new Set([
    'explore','reels','stories','direct','accounts','p','tv',
    'ar','audio','hashtag','locations','reel','shop','graphql',
    'help','about','legal','privacy','terms','_n'
  ]);

  function extractUsernames(root) {
    root.querySelectorAll('a[href]').forEach(a => {
      const match = (a.getAttribute('href') || '').match(/^\/([A-Za-z0-9._]+)\/?$/);
      if (match && !BLOCKED.has(match[1])) collected.add(match[1]);
    });
  }

  function findScrollable() {
    for (const dialog of document.querySelectorAll('[role="dialog"]')) {
      const inner = [...dialog.querySelectorAll('*')].find(el => {
        if (el.scrollHeight <= el.clientHeight + 20) return false;
        const ov = getComputedStyle(el).overflowY;
        return ov === 'scroll' || ov === 'auto';
      });
      if (inner) return { scroller: inner, root: dialog };
      if (dialog.scrollHeight > dialog.clientHeight + 20)
        return { scroller: dialog, root: dialog };
    }

    for (const div of document.querySelectorAll('div')) {
      if (div.scrollHeight <= div.clientHeight + 50) continue;
      const ov = getComputedStyle(div).overflowY;
      if (ov !== 'scroll' && ov !== 'auto') continue;
      if (div.querySelectorAll('a[href]').length >= 3)
        return { scroller: div, root: div };
    }
    return null;
  }

  async function scrape() {
    isScraping = true;
    collected.clear();

    await sleep(800);

    const found = findScrollable();
    if (!found) {
      sendError('Could not find the list dialog. Open your Followers or Following list on Instagram first, then press Start.');
      isScraping = false;
      return;
    }

    const { scroller, root } = found;
    let prevScrollTop = -1;
    let stale = 0;
    const MAX_STALE = 6;

    while (isScraping) {
      extractUsernames(root);
      sendProgress(false);

      scroller.scrollTop += 800;

      await sleep(1500);

      const cur = scroller.scrollTop;
      if (Math.abs(cur - prevScrollTop) < 5) {
        stale++;
      } else {
        stale = 0;
      }
      prevScrollTop = cur;

      if (stale >= MAX_STALE) break;
    }

    // Final sweep
    extractUsernames(root);
    isScraping = false;
    sendProgress(true);
  }

  chrome.runtime.onMessage.addListener((msg, _sender, respond) => {
    if (msg.action === 'START_SCRAPE') { if (!isScraping) scrape(); respond({ ok: true }); }
    if (msg.action === 'STOP_SCRAPE')  { isScraping = false; respond({ ok: true }); }
    return true;
  });
})();
